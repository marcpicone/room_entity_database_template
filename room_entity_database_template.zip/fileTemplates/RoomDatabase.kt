## ----------------------VARIABLE_DECLARATION-----------------------------------
#set($class = "::class")
#set($foreach = 0)
#set($entity = "")
#set($entities = "")
#set($entitiesArray = ${StringUtils.split($ENTITIES_LIST,",")})
## ---------------------------SNIPPET--------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.data.$NAME
#end
#parse("File Header.java")
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
## ----------------------------------------------------------------------
## --------------------------------------- Foreach directive
## ----------------------------------------------------------------------
## must end with "#end" , could access : foreach.count(), foreach.hasNext()
## ----------------------------------------------------------------------
#foreach($entity in $entitiesArray )
#set($ARG1 = "$entity")
import ${PACKAGE_NAME}.data.#parse("ArgToSnakeCase.kt").${ARG1}Dao
import ${PACKAGE_NAME}.domain.#parse("ArgToSnakeCase.kt").${ARG1}DTO
#end

@Database(
    entities = [#parse("RoomDbEntitiesDeclaration.kt")],
    version = 1,
    exportSchema = false
)
abstract class #parse("NameToCamelCase.kt")RoomDatabase : RoomDatabase() {
    
    #foreach($entity in ${StringUtils.split($ENTITIES_LIST,",")} )
    #set($ARG1 = "$entity")
    abstract fun #parse("ArgToLowerCamelCase.kt")Dao(): ${ARG1}Dao
    #end

    companion object {

        @Volatile
        private var instance: #parse("NameToCamelCase.kt")RoomDatabase? = null
        
        fun get#parse("NameToCamelCase.kt")RoomDatabase(context: Context): #parse("NameToCamelCase.kt")RoomDatabase  =
            instance ?: synchronized(this) {
                instance ?: buildDatabase(context)
                    .also { instance = it }
            }
            
        private fun buildDatabase(context: Context) =
            Room.databaseBuilder(context, #parse("NameToCamelCase.kt")RoomDatabase${class}.java, "#parse("NameToSnakeCase.kt")_db" )
                .fallbackToDestructiveMigration()
                .build()
    }
}
