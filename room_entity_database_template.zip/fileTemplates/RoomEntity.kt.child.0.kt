## --------------------VARIABLE_DECLARATION-------------------------------------
#set($featureToUpperCase = "$NAME.toUpperCase()")
#set($tableName = "${featureToUpperCase}_TABLE")
## ----------------------------MACRO--------------------------------------------
#macro( formatArgumentListForDataClass )
#set($argumentType = "")
#set($foreach = "")
#foreach($argumentType in ${StringUtils.split($ARGUMENT_LIST, ",")})
val ${argumentType} #if($foreach.hasNext()), 
#end
#end
#end
## ----------------------------MACRO--------------------------------------------
#macro( formatArgumentListForModelMapper )
#set($argumentType = "")
#set($argumentNameArray = [])
#set($foreach = "")
#foreach($argumentType in ${StringUtils.split($ARGUMENT_LIST, ",")})
#set($argumentNameArray = ${StringUtils.split($argumentType, ":")})
$argumentNameArray.get(0) = this.$argumentNameArray.get(0) #if($foreach.hasNext()),
#end
#end
#end
## ---------------------------SNIPPET--------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.domain.${NAME}
#end
#parse("File Header.java")
import androidx.room.Entity
import androidx.room.PrimaryKey
import ${PACKAGE_NAME}.data.${NAME}.#parse("NameToCamelCase.kt")Dao.Companion.$tableName

@Entity(tableName = $tableName)
data class #parse("NameToCamelCase.kt")DTO(
    @PrimaryKey(autoGenerate = false)
    #formatArgumentListForDataClass()
    ){
    fun toModel(): #parse("NameToCamelCase.kt"){
        return #parse("NameToCamelCase.kt")(
            #formatArgumentListForModelMapper()
        )
    }
}