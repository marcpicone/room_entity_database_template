#set($folder = "")
#set($foreach = "")
#set($rootRelativePath = "")
#set($endRootPath = "../")
#foreach ($folder in ${StringUtils.split(${PACKAGE_NAME},".")})
#set($rootRelativePath = "$!rootRelativePath../")
#if ($foreach.hasNext == false)
#set($rootRelativePath = "$!rootRelativePath$endRootPath")
#end
#end
$rootRelativePath