#set($modifiedName = ${StringUtils.removeAndHump(${NAME}, "_")})
#set($firstLetter = $modifiedName.substring(0,1).toLowerCase())
#set($theRest = $modifiedName.substring(1))
#set($snakeCaseToLowerCamelCase = ${firstLetter} + ${theRest})
$snakeCaseToLowerCamelCase