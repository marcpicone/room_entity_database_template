#set($ENTITIES_TAB = [])
#set($ENTITIES_TAB = ${StringUtils.split($ENTITIES_LIST,",")})
#set($CLASS = "::class")
#set($foreach = 0)
#set($entity = "")
#set($entities = "")
#foreach ($entity in $ENTITIES_TAB)
#if ($foreach.count == 1)
#set($entities = "${StringUtils.capitalizeFirstLetter($entity)}DTO$CLASS")
#else
#set($entities = "$entities,${StringUtils.capitalizeFirstLetter($entity)}DTO$CLASS")
#end
#end
$entities