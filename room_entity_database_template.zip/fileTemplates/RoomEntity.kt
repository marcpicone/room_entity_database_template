## ----------------------VARIABLE_DECLARATION-----------------------------------
#set($featureToUpperCase = "$NAME.toUpperCase()")
#set($tableName = "${featureToUpperCase}_TABLE")
## -----------------------VARIABLE_REFERENCE-------------------------------------
#set($argumentListDTO = $ARGUMENT_LIST)
## ---------------------------SNIPPET--------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.data.${NAME}

#end
#parse("File Header.java")
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import ${PACKAGE_NAME}.domain.${NAME}.#parse("NameToCamelCase.kt")DTO

@Dao
interface #parse("NameToCamelCase.kt")Dao {

    @Insert
    suspend fun add#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt")DTO: #parse("NameToCamelCase.kt")DTO)

    @Query("SELECT*FROM ${DS}$tableName")
    fun get#parse("NameToCamelCase.kt")s(): Flow<List<#parse("NameToCamelCase.kt")DTO>>

    @Query("SELECT*FROM ${DS}$tableName WHERE ${DS}${tableName}.id = :id ")
    suspend fun get#parse("NameToCamelCase.kt")ForId(id: String): #parse("NameToCamelCase.kt")DTO

    @Update
    suspend fun update#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt")DTO: #parse("NameToCamelCase.kt")DTO)

    @Delete
    suspend fun delete#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt")DTO: #parse("NameToCamelCase.kt")DTO)

    companion object{
        const val $tableName = "${NAME}_table"
    } 
}
