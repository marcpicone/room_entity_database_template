#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.data.${NAME}

#end
#parse("File Header.java")
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import ${PACKAGE_NAME}.domain.${NAME}.#parse("NameToCamelCase.kt")

class #parse("NameToCamelCase.kt")RepositoryImpl(
    private val #parse("NameToLowerCamelCase.kt")Dao : #parse("NameToCamelCase.kt")Dao
): #parse("NameToCamelCase.kt")Repository {

    override suspend fun add#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt"): #parse("NameToCamelCase.kt")){
        #parse("NameToLowerCamelCase.kt")Dao.add#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt").toDTO())
    }

    override fun get#parse("NameToCamelCase.kt")s(): Flow<List<#parse("NameToCamelCase.kt")>>{
        return #parse("NameToLowerCamelCase.kt")Dao.get#parse("NameToCamelCase.kt")s().map { #parse("NameToLowerCamelCase.kt")List ->
            #parse("NameToLowerCamelCase.kt")List.map { #parse("NameToLowerCamelCase.kt")DTO ->
                #parse("NameToLowerCamelCase.kt")DTO.toModel()
            }
        }
    }

    override suspend fun get#parse("NameToCamelCase.kt")ForId(id: String): #parse("NameToCamelCase.kt"){
        return #parse("NameToLowerCamelCase.kt")Dao.get#parse("NameToCamelCase.kt")ForId(id).toModel()
    }
    
    override suspend fun update#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt"): #parse("NameToCamelCase.kt")){
        #parse("NameToLowerCamelCase.kt")Dao.update#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt").toDTO())
    }

    override suspend fun delete#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt"): #parse("NameToCamelCase.kt")){
        #parse("NameToLowerCamelCase.kt")Dao.delete#parse("NameToCamelCase.kt")(#parse("NameToLowerCamelCase.kt").toDTO())
    }
}
